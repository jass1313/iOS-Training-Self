//
//  ImageSlideshow_framework.h
//  ImageSlideshow_framework
//
//  Created by Petr Zvoníček on 25.09.16.
//  Copyright © 2016 CocoaPods. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ImageSlideshow_framework.
FOUNDATION_EXPORT double ImageSlideshow_frameworkVersionNumber;

//! Project version string for ImageSlideshow_framework.
FOUNDATION_EXPORT const unsigned char ImageSlideshow_frameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ImageSlideshow_framework/PublicHeader.h>


