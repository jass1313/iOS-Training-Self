# photosAppiOS
This is the source code for my photo gallery app tutorial on Youtube https://youtu.be/QS2mWk3fAWc

<p align="center">
<img height="400" src="https://github.com/Akhilendra/photosAppiOS/blob/master/Simulator%20Screen%20Shot%20-%20iPhone%206%20-%202017-10-05%20at%2012.05.43.png" />
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<img height="400" src="https://github.com/Akhilendra/photosAppiOS/blob/master/Simulator%20Screen%20Shot%20-%20iPhone%206%20-%202017-10-05%20at%2012.06.03.png" />
<br>
<img height="400" src="https://github.com/Akhilendra/photosAppiOS/blob/master/Simulator%20Screen%20Shot%20-%20iPhone%206%20-%202017-10-05%20at%2012.06.09.png" />
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<img height="400" src="https://github.com/Akhilendra/photosAppiOS/blob/master/Simulator%20Screen%20Shot%20-%20iPhone%206%20-%202017-10-05%20at%2012.06.19.png" /> 
</p>
