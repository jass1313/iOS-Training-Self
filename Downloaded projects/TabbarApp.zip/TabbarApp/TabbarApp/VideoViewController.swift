//
//  VideoViewController.swift
//  TabbarApp
//
//  Created by Pavel Bogart on 21/02/2018.
//  Copyright © 2018 Pavel Bogart. All rights reserved.
//

import UIKit

class VideoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.white
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.title = "Videos"
    }

}
