//
//  PagingMenuController.h
//  PagingMenuController
//
//  Created by Yusuke Kita on 8/2/15.
//  Copyright (c) 2015 kitasuke. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PagingMenuController.
FOUNDATION_EXPORT double PagingMenuControllerVersionNumber;

//! Project version string for PagingMenuController.
FOUNDATION_EXPORT const unsigned char PagingMenuControllerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PagingMenuController/PublicHeader.h>


