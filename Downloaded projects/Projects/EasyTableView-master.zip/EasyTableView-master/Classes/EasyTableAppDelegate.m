//
//  EasyTableAppDelegate.m
//  EasyTableView
//
//  Created by Aleksey Novicov on 6/5/10.
//

#import "EasyTableAppDelegate.h"
#import "EasyTableViewController.h"

@implementation EasyTableAppDelegate

#pragma mark - Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    // Override point for customization after app launch.
	return YES;
}

@end
