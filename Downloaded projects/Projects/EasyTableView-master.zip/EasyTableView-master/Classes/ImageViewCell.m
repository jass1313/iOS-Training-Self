//
//  ImageViewCell.m
//  EasyTableView
//
//  Created by Aleksey Novicov on 1/7/16.
//
//

#import "ImageViewCell.h"

@implementation ImageViewCell

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
	
    // Configure the view for the selected state
}

@end
