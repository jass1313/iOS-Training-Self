import Foundation

public enum PagingContentInteraction {
  case scrolling
  case none
}
