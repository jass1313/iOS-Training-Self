import UIKit

// Nothing to see here. Check out ViewController.swift for
// implementation details.

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
  var window: UIWindow?
}
