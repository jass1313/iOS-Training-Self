//
//  arrayClass.swift
//  TableView3
//
//  Created by KiwiTech on 13/03/19.
//  Copyright © 2019 KiwiTech. All rights reserved.
//

import UIKit

class arrayClass: NSObject {
    static var array = ["jass","kiwitech","apple","dell","hp","microsoft"]
}
