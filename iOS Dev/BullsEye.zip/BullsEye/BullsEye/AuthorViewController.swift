//
//  AuthorViewController.swift
//  BullsEye
//
//  Created by KiwiTech on 06/02/19.
//  Copyright © 2019 KiwiTech. All rights reserved.
//

import UIKit

class AuthorViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
  
    @IBAction func auther() {
        dismiss(animated: true, completion: nil)
        
    }


}
